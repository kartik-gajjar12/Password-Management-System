const mongoose=require('mongoose');
mongoose.connect("mongodb+srv://ckpass:ckpass@cluster0.oh1dn.mongodb.net/password?retryWrites=true&w=majority",{useNewUrlParser:true,useUnifiedTopology: true});


var userschema=mongoose.Schema({

    username:{
        type:String,
        required:true,
        index:{
            unique:true
        }

    },
    email:{
        type:String,
        required:true,
        index:{
            unique:true
        }
    },
    password:{
        type:String,
        required:true
    },
    date:{
        type:Date,
        default:Date.now
    }

});


var usermodel=mongoose.model('user',userschema);


module.exports=usermodel;