var mongoose=require('mongoose');

mongoose.connect("mongodb+srv://ckpass:ckpass@cluster0.oh1dn.mongodb.net/password?retryWrites=true&w=majority",{useNewUrlParser:true,useUnifiedTopology: true});

var pass_detailschema=mongoose.Schema({

    username:{
        type:String,
        required:true,
    
    },
    category_name:{
        type:String,
        required:true
       
    },
    password_details:{
        type:String,
        required:true
    },
    date:{
        type:Date,
        default:Date.now
    }
});

var passdetails_modal=mongoose.model('password_details',pass_detailschema);

module.exports=passdetails_modal;